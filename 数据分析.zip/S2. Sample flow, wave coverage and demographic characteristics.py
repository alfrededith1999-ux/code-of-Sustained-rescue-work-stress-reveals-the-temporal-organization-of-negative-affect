# -*- coding: utf-8 -*-
"""
一键生成 S2 附录所需结果：
S2. Sample flow, wave coverage and demographic characteristics

适用路径：
C:\\Users\\admin\\Desktop\\24年+25年

输出目录：
C:\\Users\\admin\\Desktop\\24年+25年\\_S2_outputs

输出文件：
1. S2_results.xlsx
2. S2_long_minimal.csv
3. S2_file_inventory.csv
4. S2_data_quality_flags.csv

功能：
- 递归扫描根目录下所有 xlsx/xls 文件
- 自动识别季度：24T1、24T2、24T3、24T4、25T1、25T2、25T3、25T4
- 自动识别姓名、电话、性别、年龄、婚姻、学历、岗位、职务、单位等字段
- 使用姓名+电话等信息构造匿名 participant_id
- 输出样本流程、文件覆盖、波次覆盖、每人可用波次数、人口学特征
- 计算 DASS-21 / PHQ-9 / GAD-7 / MSPSS / SCS / SCSQ / 生活事件影响列的可用性和粗略总分
"""

from __future__ import annotations

import os
import re
import json
import hashlib
import warnings
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")


# =========================
# 0. 基本路径设置
# =========================

ROOT = Path(r"C:\Users\admin\Desktop\24年+25年")
OUT_DIR = ROOT / "_S2_outputs"
OUT_DIR.mkdir(parents=True, exist_ok=True)

OUT_XLSX = OUT_DIR / "S2_results.xlsx"
OUT_LONG_CSV = OUT_DIR / "S2_long_minimal.csv"
OUT_FILE_CSV = OUT_DIR / "S2_file_inventory.csv"
OUT_FLAG_CSV = OUT_DIR / "S2_data_quality_flags.csv"


# =========================
# 1. 通用工具函数
# =========================

def norm_text(x: Any) -> str:
    """标准化列名和文本，用于模糊匹配。"""
    if pd.isna(x):
        return ""
    s = str(x)
    s = s.replace("\u3000", " ")
    s = s.replace("\xa0", " ")
    s = re.sub(r"\s+", "", s)
    s = s.replace("（", "(").replace("）", ")")
    s = s.replace("—", "-").replace("–", "-")
    return s.strip()


def clean_person_text(x: Any) -> str:
    """清理姓名等个人文本。"""
    if pd.isna(x):
        return ""
    s = str(x).strip()
    s = re.sub(r"\s+", "", s)
    s = s.replace("　", "")
    return s


def clean_phone(x: Any) -> str:
    """提取手机号/联系电话中的数字。"""
    if pd.isna(x):
        return ""
    s = str(x)
    digits = re.sub(r"\D", "", s)
    # 只保留长度较合理的号码，避免把年龄、编号误作电话
    if len(digits) >= 7:
        return digits
    return ""


def safe_hash(s: str, n: int = 16) -> str:
    """匿名哈希ID。"""
    s = str(s)
    return hashlib.sha256(s.encode("utf-8")).hexdigest()[:n]


def find_first_col(cols: List[str], include: List[str], exclude: Optional[List[str]] = None) -> Optional[str]:
    """在列名中找到第一个包含 include 全部关键词且不包含 exclude 的列。"""
    exclude = exclude or []
    for c in cols:
        nc = norm_text(c)
        ok = all(k in nc for k in include)
        bad = any(k in nc for k in exclude)
        if ok and not bad:
            return c
    return None


def find_cols(cols: List[str], include_any: Optional[List[str]] = None,
              include_all: Optional[List[str]] = None,
              exclude: Optional[List[str]] = None) -> List[str]:
    """按关键词批量找列。"""
    include_any = include_any or []
    include_all = include_all or []
    exclude = exclude or []
    found = []
    for c in cols:
        nc = norm_text(c)
        if include_all and not all(k in nc for k in include_all):
            continue
        if include_any and not any(k in nc for k in include_any):
            continue
        if any(k in nc for k in exclude):
            continue
        found.append(c)
    return found


def parse_quarter_from_path(path: Path) -> Tuple[str, str, str]:
    """
    从文件夹或文件名解析季度。
    返回：
    wave: 24T1
    year: 2024
    quarter: Q1
    """
    text = str(path)
    text_norm = norm_text(text)

    # 先匹配 24年1季度 / 25年4季度
    m = re.search(r"(20)?(24|25)年([一二三四1234])季度", text_norm)
    if not m:
        # 匹配 2024年第一季度 / 2024年2季度
        m = re.search(r"(2024|2025)年(第?[一二三四1234])季度", text_norm)

    if m:
        if m.group(1) in ["2024", "2025"]:
            year_full = m.group(1)
            q_raw = m.group(2)
        else:
            yy = m.group(2)
            year_full = "20" + yy
            q_raw = m.group(3)

        q_map = {"一": "1", "二": "2", "三": "3", "四": "4",
                 "第一": "1", "第二": "2", "第三": "3", "第四": "4",
                 "1": "1", "2": "2", "3": "3", "4": "4"}
        q_num = q_map.get(q_raw.replace("第", ""), q_raw)
        yy2 = year_full[-2:]
        return f"{yy2}T{q_num}", year_full, f"Q{q_num}"

    # 兼容 24Q1 / 25Q4
    m2 = re.search(r"(24|25)Q([1234])", text_norm, re.I)
    if m2:
        yy = m2.group(1)
        q_num = m2.group(2)
        return f"{yy}T{q_num}", "20" + yy, f"Q{q_num}"

    return "Unknown", "Unknown", "Unknown"


def extract_unit_from_filename(path: Path) -> str:
    """
    从文件名提取单位。
    示例：
    246963109_按序号_省森林消防总队2024年第一季度心理测评_49_38.xlsx
    """
    stem = path.stem
    s = stem

    if "按序号_" in s:
        s = s.split("按序号_", 1)[1]

    # 去掉尾部 _49_38 这类统计数
    s = re.sub(r"_\d+_\d+$", "", s)

    # 去掉“2024年第一季度心理测评”等尾巴
    s = re.sub(r"20\d{2}年.*?心理测评", "", s)
    s = re.sub(r"20\d{2}年.*?季度.*", "", s)

    s = s.strip("_- ")
    if not s:
        s = path.parent.name
    return s


def to_numeric_fuzzy(x: Any) -> float:
    """
    将问卷答案尽量转成数字。
    兼容：
    - 已经是数字
    - '1'
    - '1. 从不'
    - '强烈不同意'
    - '非常符合'
    注意：不同量表锚点不同，此处仅用于粗略总分和可用性检查。
    严格计分建议后续按量表单独校准。
    """
    if pd.isna(x):
        return np.nan

    if isinstance(x, (int, float, np.integer, np.floating)):
        return float(x)

    s = str(x).strip()
    if s == "" or s in ["nan", "None", "NULL", "#NULL!"]:
        return np.nan

    # 提取开头或文本中的数字
    m = re.search(r"[-+]?\d+(\.\d+)?", s)
    if m:
        try:
            return float(m.group(0))
        except Exception:
            pass

    # 常见李克特文本映射：只作为兜底
    maps = {
        "从不": 0,
        "完全不符合": 0,
        "不符合": 0,
        "有时": 1,
        "有一点": 1,
        "比较符合": 2,
        "经常": 2,
        "非常符合": 3,
        "总是": 3,

        "强烈不同意": 1,
        "非常不同意": 1,
        "不同意": 2,
        "有点不同意": 3,
        "中立": 4,
        "不确定": 4,
        "有点同意": 5,
        "同意": 6,
        "强烈同意": 7,
        "非常同意": 7,
    }
    for k, v in maps.items():
        if k in s:
            return float(v)

    return np.nan


def numeric_series(df: pd.DataFrame, col: str) -> pd.Series:
    if col is None or col not in df.columns:
        return pd.Series([np.nan] * len(df), index=df.index)
    return df[col].apply(to_numeric_fuzzy)


def first_nonempty(row: pd.Series, cols: List[str]) -> Any:
    for c in cols:
        if c in row.index:
            v = row[c]
            if pd.notna(v) and str(v).strip() != "":
                return v
    return np.nan


def build_participant_id(row: pd.Series,
                         name_col: Optional[str],
                         phone_col: Optional[str],
                         sex_col: Optional[str],
                         age_col: Optional[str],
                         unit_value: str) -> str:
    name = clean_person_text(row.get(name_col, "")) if name_col else ""
    phone = clean_phone(row.get(phone_col, "")) if phone_col else ""
    sex = clean_person_text(row.get(sex_col, "")) if sex_col else ""
    age_raw = row.get(age_col, "") if age_col else ""
    age = str(to_numeric_fuzzy(age_raw)) if pd.notna(age_raw) else ""

    if phone:
        key = f"phone:{phone}|name:{name}"
    elif name:
        key = f"name:{name}|sex:{sex}|age:{age}|unit:{unit_value}"
    else:
        # 最后兜底：用行号会导致无法跨波匹配，但至少保留记录
        key = f"noid|unit:{unit_value}|rand:{np.random.random()}"

    return safe_hash(key)


# =========================
# 2. 量表列识别函数
# =========================

DASS_KEYWORDS = {
    1: "很难让自己安静下来",
    2: "口干舌燥",
    3: "不能积极乐观",
    4: "呼吸困难",
    5: "很难主动去做事",
    6: "过度反应",
    7: "颤抖",
    8: "精神紧张",
    9: "恐慌而出洋相",
    10: "未来没什么可期待",
    11: "烦躁不安",
    12: "很难放松",
    13: "消沉和沮丧",
    14: "无法容忍",
    15: "惊慌失措",
    16: "无法充满热情",
    17: "存在没有价值",
    18: "小事而生气",
    19: "心跳过快",
    20: "无缘无故地感到害怕",
    21: "生活毫无意义",
}

DASS_DEP = [3, 5, 10, 13, 16, 17, 21]
DASS_ANX = [2, 4, 7, 9, 15, 19, 20]
DASS_STR = [1, 6, 8, 11, 12, 14, 18]


def find_item_col_by_keyword(cols: List[str], item_no: int, keyword: str) -> Optional[str]:
    """按题号+关键词找题项列。"""
    for c in cols:
        nc = norm_text(c)
        # 兼容 “—1.题目” 或 “1.题目”
        has_no = re.search(rf"(^|[-—]|。|；|;){item_no}[\.．、]", nc) is not None
        if has_no and keyword in nc:
            return c
    # 只按关键词兜底
    candidates = [c for c in cols if keyword in norm_text(c)]
    return candidates[0] if candidates else None


def find_dass_cols(cols: List[str]) -> Dict[int, str]:
    out = {}
    for i, kw in DASS_KEYWORDS.items():
        c = find_item_col_by_keyword(cols, i, kw)
        if c:
            out[i] = c
    return out


PHQ_KEYWORDS = {
    1: "做事时提不起劲",
    2: "感到心情低落",
    3: "入睡困难",
    4: "疲倦",
    5: "食欲",
    6: "觉得自己很糟",
    7: "注意力",
    8: "动作或说话速度缓慢",
    9: "伤害自己",
}

GAD_KEYWORDS = {
    1: "感到紧张",
    2: "无法停止担忧",
    3: "担忧太多",
    4: "很难放松",
    5: "坐立不安",
    6: "变得容易烦恼",
    7: "感到害怕",
}

# MSPSS 12题关键词
MSPSS_KEYWORDS = {
    1: "需要的时候",
    2: "分享我的快乐和悲伤",
    3: "家人非常愿意帮助我",
    4: "情感上的帮助和支持",
    5: "真正的安慰来源",
    6: "朋友非常愿意帮助我",
    7: "可以依靠我的朋友",
    8: "和家人谈论",
    9: "分享快乐和悲伤的朋友",
    10: "关心我的感受",
    11: "家人愿意帮助我做决定",
    12: "和朋友谈论",
}

# SCS 12题关键词
SCS_KEYWORDS = {
    1: "不断地想自己的不足",
    2: "理解和包容自己",
    3: "平和的心态",
    4: "大多数人可能比我快乐",
    5: "失败看成人生经历",
    6: "关心自己",
    7: "情绪保持稳定",
    8: "一个人在承受失败",
    9: "纠结于不顺心",
    10: "大部分人和我一样",
    11: "不满和批判",
    12: "不能容忍",
}
SCS_REVERSE = [1, 4, 8, 9, 11, 12]  # 1-5计分时反向

# SCSQ 20题关键词
SCSQ_KEYWORDS = {
    1: "工作学习或一些其他活动解脱",
    2: "与人交谈",
    3: "看到事物好的一面",
    4: "改变自己的想法",
    5: "不把问题看得太严重",
    6: "坚持自己的立场",
    7: "几种不同的解决问题",
    8: "寻求建议",
    9: "改变原来的一些做法",
    10: "借鉴他人处理",
    11: "寻求业余爱好",
    12: "克制自己的失望",
    13: "休息或休假",
    14: "吸烟",
    15: "时间会改变现状",
    16: "试图忘记",
    17: "依靠别人解决",
    18: "接受现实",
    19: "幻想",
    20: "自己安慰自己",
}
SCSQ_POS = list(range(1, 13))
SCSQ_NEG = list(range(13, 21))


def score_items(df: pd.DataFrame, item_cols: Dict[int, str], item_ids: List[int],
                reverse_ids: Optional[List[int]] = None,
                reverse_max: Optional[int] = None,
                min_valid_ratio: float = 0.5) -> Tuple[pd.Series, pd.Series]:
    """
    计算题项总分和有效题项数。
    reverse_ids: 需要反向计分的题号
    reverse_max: 如果是1-5计分，反向为 6-x；如果1-7，反向为8-x
    """
    reverse_ids = reverse_ids or []
    vals = []
    for i in item_ids:
        c = item_cols.get(i)
        if c is None:
            vals.append(pd.Series([np.nan] * len(df), index=df.index))
        else:
            s = numeric_series(df, c)
            if i in reverse_ids and reverse_max is not None:
                s = (reverse_max + 1) - s
            vals.append(s)

    mat = pd.concat(vals, axis=1)
    valid_n = mat.notna().sum(axis=1)
    need_n = max(1, int(np.ceil(len(item_ids) * min_valid_ratio)))
    total = mat.sum(axis=1, min_count=need_n)
    return total, valid_n


def find_keyword_items(cols: List[str], keywords: Dict[int, str]) -> Dict[int, str]:
    out = {}
    for i, kw in keywords.items():
        c = find_item_col_by_keyword(cols, i, kw)
        if c:
            out[i] = c
    return out


# =========================
# 3. 读取所有Excel文件
# =========================

def read_excel_safely(path: Path) -> Optional[pd.DataFrame]:
    """读取 Excel 第一张表。"""
    try:
        # 优先读第一张表
        df = pd.read_excel(path, sheet_name=0, dtype=object, engine=None)
        df = df.dropna(how="all")
        # 删除空列
        df = df.loc[:, ~df.columns.astype(str).str.match(r"^Unnamed")]
        return df
    except Exception as e:
        print(f"[读取失败] {path} -> {e}")
        return None


def collect_files(root: Path) -> List[Path]:
    files = []
    for ext in ["*.xlsx", "*.xls"]:
        files.extend(root.rglob(ext))
    files = [p for p in files if not p.name.startswith("~$") and "_S2_outputs" not in str(p)]
    return sorted(files)


# =========================
# 4. 主处理函数
# =========================

def process_all_files(root: Path) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    files = collect_files(root)

    all_rows = []
    file_inventory = []
    flags = []

    print(f"发现 Excel 文件数：{len(files)}")

    for idx, path in enumerate(files, 1):
        wave, year, quarter = parse_quarter_from_path(path)
        unit_from_file = extract_unit_from_filename(path)

        df = read_excel_safely(path)
        if df is None:
            flags.append({
                "file": str(path),
                "issue": "read_failed",
                "detail": "无法读取文件"
            })
            continue

        cols = list(df.columns)
        raw_n = len(df)

        # 基本列识别
        time_col = find_first_col(cols, ["提交答卷时间"])
        name_col = find_first_col(cols, ["姓名"])
        phone_col = find_first_col(cols, ["联系电话"])
        sex_col = find_first_col(cols, ["性别"])
        age_col = find_first_col(cols, ["年龄"])
        ethnicity_col = find_first_col(cols, ["民族"])
        unit_col = find_first_col(cols, ["具体单位"])
        edu_col = find_first_col(cols, ["学历"])
        only_child_col = find_first_col(cols, ["独生子女"])
        marital_col = find_first_col(cols, ["婚姻状况"])
        children_col = find_first_col(cols, ["子女情况"])
        service_year_col = find_first_col(cols, ["消防工作年限"])
        position_col = find_first_col(cols, ["职务"])
        job_col = find_first_col(cols, ["工作岗位"])

        # 量表列识别
        dass_cols = find_dass_cols(cols)
        phq_cols = find_keyword_items(cols, PHQ_KEYWORDS)
        gad_cols = find_keyword_items(cols, GAD_KEYWORDS)
        mspss_cols = find_keyword_items(cols, MSPSS_KEYWORDS)
        scs_cols = find_keyword_items(cols, SCS_KEYWORDS)
        scsq_cols = find_keyword_items(cols, SCSQ_KEYWORDS)

        # 生活事件影响列
        event_impact_cols = find_cols(
            cols,
            include_all=["该事件对您", "影响有多大"],
            exclude=["此题请选择"]
        )
        event_count_cols = find_cols(
            cols,
            include_all=["该事件共发生过几次"],
            exclude=["此题请选择"]
        )

        # 文件清单
        file_inventory.append({
            "file_path": str(path),
            "parent_folder": path.parent.name,
            "file_name": path.name,
            "wave": wave,
            "year": year,
            "quarter": quarter,
            "unit_from_file": unit_from_file,
            "raw_rows": raw_n,
            "n_columns": len(cols),
            "has_name": name_col is not None,
            "has_phone": phone_col is not None,
            "has_submit_time": time_col is not None,
            "dass_items_found": len(dass_cols),
            "phq_items_found": len(phq_cols),
            "gad_items_found": len(gad_cols),
            "mspss_items_found": len(mspss_cols),
            "scs_items_found": len(scs_cols),
            "scsq_items_found": len(scsq_cols),
            "event_impact_cols_found": len(event_impact_cols),
        })

        if wave == "Unknown":
            flags.append({
                "file": str(path),
                "issue": "unknown_wave",
                "detail": "无法从路径或文件名解析季度"
            })

        if name_col is None and phone_col is None:
            flags.append({
                "file": str(path),
                "issue": "no_identity_columns",
                "detail": "未找到姓名或联系电话列，跨波匹配可能失败"
            })

        if len(dass_cols) < 10 and len(phq_cols) < 5 and len(gad_cols) < 5:
            flags.append({
                "file": str(path),
                "issue": "few_core_mental_health_items",
                "detail": f"DASS={len(dass_cols)}, PHQ={len(phq_cols)}, GAD={len(gad_cols)}"
            })

        # 计算量表粗分和有效题项数
        if len(dass_cols) > 0:
            dass_dep, dass_dep_n = score_items(df, dass_cols, DASS_DEP)
            dass_anx, dass_anx_n = score_items(df, dass_cols, DASS_ANX)
            dass_str, dass_str_n = score_items(df, dass_cols, DASS_STR)
            dass_total, dass_total_n = score_items(df, dass_cols, list(range(1, 22)))
        else:
            dass_dep = dass_anx = dass_str = dass_total = pd.Series([np.nan] * len(df), index=df.index)
            dass_dep_n = dass_anx_n = dass_str_n = dass_total_n = pd.Series([0] * len(df), index=df.index)

        phq_total, phq_n = score_items(df, phq_cols, list(PHQ_KEYWORDS.keys())) if phq_cols else (
            pd.Series([np.nan] * len(df), index=df.index), pd.Series([0] * len(df), index=df.index)
        )
        gad_total, gad_n = score_items(df, gad_cols, list(GAD_KEYWORDS.keys())) if gad_cols else (
            pd.Series([np.nan] * len(df), index=df.index), pd.Series([0] * len(df), index=df.index)
        )
        mspss_total, mspss_n = score_items(df, mspss_cols, list(MSPSS_KEYWORDS.keys())) if mspss_cols else (
            pd.Series([np.nan] * len(df), index=df.index), pd.Series([0] * len(df), index=df.index)
        )
        scs_total, scs_n = score_items(df, scs_cols, list(SCS_KEYWORDS.keys()),
                                       reverse_ids=SCS_REVERSE, reverse_max=5) if scs_cols else (
            pd.Series([np.nan] * len(df), index=df.index), pd.Series([0] * len(df), index=df.index)
        )
        scsq_pos, scsq_pos_n = score_items(df, scsq_cols, SCSQ_POS) if scsq_cols else (
            pd.Series([np.nan] * len(df), index=df.index), pd.Series([0] * len(df), index=df.index)
        )
        scsq_neg, scsq_neg_n = score_items(df, scsq_cols, SCSQ_NEG) if scsq_cols else (
            pd.Series([np.nan] * len(df), index=df.index), pd.Series([0] * len(df), index=df.index)
        )

        # 事件影响负荷
        if event_impact_cols:
            event_impact_mat = pd.concat([numeric_series(df, c) for c in event_impact_cols], axis=1)
            event_impact_sum = event_impact_mat.sum(axis=1, min_count=1)
            event_impact_n = event_impact_mat.notna().sum(axis=1)
        else:
            event_impact_sum = pd.Series([np.nan] * len(df), index=df.index)
            event_impact_n = pd.Series([0] * len(df), index=df.index)

        # 行级最小长表
        for ridx, row in df.iterrows():
            unit_from_col = clean_person_text(row.get(unit_col, "")) if unit_col else ""
            unit_final = unit_from_col if unit_from_col else unit_from_file

            pid = build_participant_id(row, name_col, phone_col, sex_col, age_col, unit_final)

            out = {
                "participant_id": pid,
                "wave": wave,
                "year": year,
                "quarter": quarter,
                "source_file": path.name,
                "source_folder": path.parent.name,
                "unit_from_file": unit_from_file,
                "unit": unit_final,
                "submit_time": row.get(time_col, np.nan) if time_col else np.nan,

                "sex": row.get(sex_col, np.nan) if sex_col else np.nan,
                "age": to_numeric_fuzzy(row.get(age_col, np.nan)) if age_col else np.nan,
                "ethnicity": row.get(ethnicity_col, np.nan) if ethnicity_col else np.nan,
                "education": row.get(edu_col, np.nan) if edu_col else np.nan,
                "only_child": row.get(only_child_col, np.nan) if only_child_col else np.nan,
                "marital_status": row.get(marital_col, np.nan) if marital_col else np.nan,
                "children_status": row.get(children_col, np.nan) if children_col else np.nan,
                "service_years": to_numeric_fuzzy(row.get(service_year_col, np.nan)) if service_year_col else np.nan,
                "position": row.get(position_col, np.nan) if position_col else np.nan,
                "job_position": row.get(job_col, np.nan) if job_col else np.nan,

                "dass_depression": dass_dep.loc[ridx],
                "dass_anxiety": dass_anx.loc[ridx],
                "dass_stress": dass_str.loc[ridx],
                "dass_total": dass_total.loc[ridx],
                "dass_items_valid": dass_total_n.loc[ridx],

                "phq9_total": phq_total.loc[ridx],
                "phq9_items_valid": phq_n.loc[ridx],
                "gad7_total": gad_total.loc[ridx],
                "gad7_items_valid": gad_n.loc[ridx],

                "mspss_total": mspss_total.loc[ridx],
                "mspss_items_valid": mspss_n.loc[ridx],
                "scs_total": scs_total.loc[ridx],
                "scs_items_valid": scs_n.loc[ridx],

                "scsq_positive": scsq_pos.loc[ridx],
                "scsq_negative": scsq_neg.loc[ridx],
                "scsq_net": scsq_pos.loc[ridx] - scsq_neg.loc[ridx]
                if pd.notna(scsq_pos.loc[ridx]) and pd.notna(scsq_neg.loc[ridx]) else np.nan,
                "scsq_pos_items_valid": scsq_pos_n.loc[ridx],
                "scsq_neg_items_valid": scsq_neg_n.loc[ridx],

                "event_impact_sum": event_impact_sum.loc[ridx],
                "event_impact_items_valid": event_impact_n.loc[ridx],
            }

            # 核心心理指标可用
            core_available = (
                pd.notna(out["dass_total"]) or
                pd.notna(out["phq9_total"]) or
                pd.notna(out["gad7_total"]) or
                pd.notna(out["dass_depression"]) or
                pd.notna(out["dass_anxiety"]) or
                pd.notna(out["dass_stress"])
            )
            out["core_mental_health_available"] = bool(core_available)

            all_rows.append(out)

        print(f"[{idx}/{len(files)}] {wave} | {path.name} | rows={raw_n}")

    long_df = pd.DataFrame(all_rows)
    file_df = pd.DataFrame(file_inventory)
    flags_df = pd.DataFrame(flags)

    return long_df, file_df, flags_df


# =========================
# 5. 汇总表生成
# =========================

def pct(x: float) -> float:
    return round(x * 100, 2)


def make_sample_flow(long_df: pd.DataFrame, file_df: pd.DataFrame) -> pd.DataFrame:
    raw_submissions = int(file_df["raw_rows"].sum()) if len(file_df) else 0

    # 文件内读取后的全部行
    all_records = len(long_df)

    # 按 participant_id + wave 去重，保留同一人同一季度第一条
    dedup_wave = long_df.drop_duplicates(subset=["participant_id", "wave"])

    # 至少两波
    wave_count = dedup_wave.groupby("participant_id")["wave"].nunique()
    participants_linked = int(dedup_wave["participant_id"].nunique())
    participants_ge2 = int((wave_count >= 2).sum())

    ids_ge2 = set(wave_count[wave_count >= 2].index)
    tmp = dedup_wave[dedup_wave["participant_id"].isin(ids_ge2)].copy()

    # 至少一项核心心理健康指标
    core_by_id = tmp.groupby("participant_id")["core_mental_health_available"].max()
    ids_core = set(core_by_id[core_by_id == True].index)

    final_df = tmp[tmp["participant_id"].isin(ids_core)].copy()
    final_participants = int(final_df["participant_id"].nunique())
    final_obs = int(len(final_df))

    flow = pd.DataFrame([
        {"Step": "Raw submissions", "Description": "Total questionnaire rows across all scanned Excel files", "N": raw_submissions},
        {"Step": "Rows read into Python", "Description": "Non-empty rows successfully read from Excel files", "N": all_records},
        {"Step": "Linked participants", "Description": "Unique anonymized participant IDs after linkage", "N": participants_linked},
        {"Step": "Participants with ≥2 waves", "Description": "Participants observed in at least two waves", "N": participants_ge2},
        {"Step": "Final analytic participants", "Description": "Participants with ≥2 waves and at least one core mental-health indicator", "N": final_participants},
        {"Step": "Final longitudinal observations", "Description": "Wave-level observations contributed by final analytic participants", "N": final_obs},
    ])
    return flow


def get_final_long_df(long_df: pd.DataFrame) -> pd.DataFrame:
    """返回符合至少2波且至少一个核心心理健康指标的去重长表。"""
    dedup_wave = long_df.drop_duplicates(subset=["participant_id", "wave"]).copy()
    wave_count = dedup_wave.groupby("participant_id")["wave"].nunique()
    ids_ge2 = set(wave_count[wave_count >= 2].index)
    tmp = dedup_wave[dedup_wave["participant_id"].isin(ids_ge2)].copy()
    core_by_id = tmp.groupby("participant_id")["core_mental_health_available"].max()
    ids_core = set(core_by_id[core_by_id == True].index)
    final_df = tmp[tmp["participant_id"].isin(ids_core)].copy()
    return final_df


def make_wave_coverage(final_df: pd.DataFrame) -> pd.DataFrame:
    wave_order = ["24T1", "24T2", "24T3", "24T4", "25T1", "25T2", "25T3", "25T4"]
    rows = []
    for w in wave_order:
        d = final_df[final_df["wave"] == w]
        rows.append({
            "Wave": w,
            "Year": d["year"].dropna().iloc[0] if len(d) and d["year"].notna().any() else "",
            "Quarter": d["quarter"].dropna().iloc[0] if len(d) and d["quarter"].notna().any() else "",
            "Observations": len(d),
            "Participants": d["participant_id"].nunique(),
            "Core mental-health available": int(d["core_mental_health_available"].sum()) if len(d) else 0,
            "DASS available": int(d["dass_total"].notna().sum()) if len(d) else 0,
            "PHQ-9 available": int(d["phq9_total"].notna().sum()) if len(d) else 0,
            "GAD-7 available": int(d["gad7_total"].notna().sum()) if len(d) else 0,
            "MSPSS available": int(d["mspss_total"].notna().sum()) if len(d) else 0,
            "SCS available": int(d["scs_total"].notna().sum()) if len(d) else 0,
            "SCSQ available": int(d["scsq_net"].notna().sum()) if len(d) else 0,
        })
    return pd.DataFrame(rows)


def make_available_waves(final_df: pd.DataFrame) -> pd.DataFrame:
    wc = final_df.groupby("participant_id")["wave"].nunique()
    tab = wc.value_counts().sort_index().rename_axis("Available waves").reset_index(name="Number of participants")
    total = tab["Number of participants"].sum()
    tab["Percentage"] = tab["Number of participants"].apply(lambda x: round(x / total * 100, 2) if total else 0)
    return tab


def summarize_categorical(s: pd.Series, top_n: int = 20) -> pd.DataFrame:
    s2 = s.dropna().astype(str).str.strip()
    s2 = s2[s2 != ""]
    vc = s2.value_counts().head(top_n)
    total = len(s2)
    return pd.DataFrame({
        "Category": vc.index,
        "n": vc.values,
        "Percent among non-missing": [round(v / total * 100, 2) if total else 0 for v in vc.values]
    })


def summarize_numeric(s: pd.Series) -> Dict[str, Any]:
    x = pd.to_numeric(s, errors="coerce").dropna()
    if len(x) == 0:
        return {
            "N valid": 0, "Mean": np.nan, "SD": np.nan,
            "Median": np.nan, "IQR": np.nan, "Min": np.nan, "Max": np.nan
        }
    return {
        "N valid": int(len(x)),
        "Mean": round(float(x.mean()), 3),
        "SD": round(float(x.std(ddof=1)), 3) if len(x) > 1 else 0,
        "Median": round(float(x.median()), 3),
        "IQR": round(float(x.quantile(0.75) - x.quantile(0.25)), 3),
        "Min": round(float(x.min()), 3),
        "Max": round(float(x.max()), 3),
    }


def make_demographics(final_df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, pd.DataFrame]]:
    """
    人口学摘要：
    对每个参与者取第一次观测作为基线。
    """
    wave_order_map = {w: i for i, w in enumerate(["24T1", "24T2", "24T3", "24T4", "25T1", "25T2", "25T3", "25T4"], 1)}
    tmp = final_df.copy()
    tmp["wave_order"] = tmp["wave"].map(wave_order_map).fillna(999)
    base = tmp.sort_values(["participant_id", "wave_order"]).drop_duplicates("participant_id").copy()

    numeric_vars = ["age", "service_years", "dass_depression", "dass_anxiety", "dass_stress",
                    "phq9_total", "gad7_total", "mspss_total", "scs_total", "scsq_positive",
                    "scsq_negative", "scsq_net", "event_impact_sum"]

    rows = []
    for var in numeric_vars:
        if var in base.columns:
            d = summarize_numeric(base[var])
            d["Variable"] = var
            rows.append(d)
    num_summary = pd.DataFrame(rows)
    if len(num_summary):
        num_summary = num_summary[["Variable", "N valid", "Mean", "SD", "Median", "IQR", "Min", "Max"]]

    cat_vars = ["sex", "ethnicity", "education", "only_child", "marital_status",
                "children_status", "position", "job_position", "unit"]
    cat_tables = {}
    for var in cat_vars:
        if var in base.columns:
            cat_tables[var] = summarize_categorical(base[var], top_n=30)

    return num_summary, cat_tables


def make_unit_file_counts(final_df: pd.DataFrame) -> pd.DataFrame:
    return (
        final_df.groupby(["wave", "unit"], dropna=False)
        .agg(
            observations=("participant_id", "size"),
            participants=("participant_id", "nunique")
        )
        .reset_index()
        .sort_values(["wave", "unit"])
    )


# =========================
# 6. 输出Excel
# =========================

def autosize_excel(writer: pd.ExcelWriter, sheet_name: str, df: pd.DataFrame, max_width: int = 40):
    """简单自动列宽。"""
    worksheet = writer.sheets[sheet_name]
    for idx, col in enumerate(df.columns):
        series = df[col].astype(str)
        width = min(max(series.map(len).max() if len(series) else 10, len(str(col))) + 2, max_width)
        worksheet.set_column(idx, idx, width)


def export_results(long_df: pd.DataFrame, file_df: pd.DataFrame, flags_df: pd.DataFrame):
    final_df = get_final_long_df(long_df)
    sample_flow = make_sample_flow(long_df, file_df)
    wave_coverage = make_wave_coverage(final_df)
    available_waves = make_available_waves(final_df)
    demo_num, demo_cats = make_demographics(final_df)
    unit_counts = make_unit_file_counts(final_df)

    # 输出CSV
    final_df.to_csv(OUT_LONG_CSV, index=False, encoding="utf-8-sig")
    file_df.to_csv(OUT_FILE_CSV, index=False, encoding="utf-8-sig")
    flags_df.to_csv(OUT_FLAG_CSV, index=False, encoding="utf-8-sig")

    # 输出Excel
    with pd.ExcelWriter(OUT_XLSX, engine="xlsxwriter") as writer:
        readme = pd.DataFrame([
            {"Item": "Root", "Value": str(ROOT)},
            {"Item": "Files scanned", "Value": len(file_df)},
            {"Item": "Rows read", "Value": len(long_df)},
            {"Item": "Final participants", "Value": final_df["participant_id"].nunique()},
            {"Item": "Final observations", "Value": len(final_df)},
            {"Item": "Note", "Value": "Participant IDs are anonymized hashes. Raw names and phone numbers are not exported."},
        ])
        readme.to_excel(writer, sheet_name="README", index=False)
        sample_flow.to_excel(writer, sheet_name="S2_sample_flow", index=False)
        wave_coverage.to_excel(writer, sheet_name="S2_wave_coverage", index=False)
        available_waves.to_excel(writer, sheet_name="S2_available_waves", index=False)
        demo_num.to_excel(writer, sheet_name="S2_demo_numeric", index=False)
        unit_counts.to_excel(writer, sheet_name="S2_unit_counts", index=False)
        file_df.to_excel(writer, sheet_name="File_inventory", index=False)
        flags_df.to_excel(writer, sheet_name="Data_quality_flags", index=False)

        # 分类变量分布，每个变量一个sheet，避免太宽
        for var, tab in demo_cats.items():
            sheet = f"cat_{var}"[:31]
            tab.to_excel(writer, sheet_name=sheet, index=False)

        # 长表只放前 5000 行到 Excel，完整长表见 CSV
        final_df.head(5000).to_excel(writer, sheet_name="Long_minimal_preview", index=False)

        # 设置格式
        workbook = writer.book
        header_fmt = workbook.add_format({
            "bold": True,
            "border": 1,
            "bg_color": "#F2F2F2",
            "align": "center",
            "valign": "vcenter"
        })
        body_fmt = workbook.add_format({
            "border": 0,
            "valign": "top"
        })

        for sheet_name, worksheet in writer.sheets.items():
            worksheet.freeze_panes(1, 0)
            worksheet.set_zoom(90)
            # 给表头加格式
            try:
                df_written = {
                    "README": readme,
                    "S2_sample_flow": sample_flow,
                    "S2_wave_coverage": wave_coverage,
                    "S2_available_waves": available_waves,
                    "S2_demo_numeric": demo_num,
                    "S2_unit_counts": unit_counts,
                    "File_inventory": file_df,
                    "Data_quality_flags": flags_df,
                    "Long_minimal_preview": final_df.head(5000),
                }.get(sheet_name)

                if df_written is None:
                    # 分类表
                    for var, tab in demo_cats.items():
                        if sheet_name == f"cat_{var}"[:31]:
                            df_written = tab
                            break

                if df_written is not None:
                    for col_num, value in enumerate(df_written.columns.values):
                        worksheet.write(0, col_num, value, header_fmt)
                    autosize_excel(writer, sheet_name, df_written)
            except Exception:
                pass

    print("\n完成。输出文件：")
    print(f"1) {OUT_XLSX}")
    print(f"2) {OUT_LONG_CSV}")
    print(f"3) {OUT_FILE_CSV}")
    print(f"4) {OUT_FLAG_CSV}")


# =========================
# 7. 主程序入口
# =========================

def main():
    if not ROOT.exists():
        raise FileNotFoundError(f"根目录不存在：{ROOT}")

    long_df, file_df, flags_df = process_all_files(ROOT)
    export_results(long_df, file_df, flags_df)

    # 简要打印
    final_df = get_final_long_df(long_df)
    print("\n====== S2 简要结果 ======")
    print(f"扫描文件数：{len(file_df)}")
    print(f"读取总行数：{len(long_df)}")
    print(f"最终参与者数：{final_df['participant_id'].nunique()}")
    print(f"最终纵向观测数：{len(final_df)}")
    print("\n各波次覆盖：")
    print(make_wave_coverage(final_df).to_string(index=False))
    print("\n每人可用波次数：")
    print(make_available_waves(final_df).to_string(index=False))


if __name__ == "__main__":
    main()
